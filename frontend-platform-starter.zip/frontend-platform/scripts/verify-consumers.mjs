import { execFileSync } from "node:child_process";
import {
  existsSync,
  mkdtempSync,
  readFileSync,
  realpathSync,
  rmSync,
} from "node:fs";
import { tmpdir } from "node:os";
import { createRequire } from "node:module";
import { join, resolve } from "node:path";
import assert from "node:assert/strict";
const yarn = process.env.npm_execpath;
if (!yarn) throw Error("Run this script using yarn verify:consumers");
const runYarn = (cwd, ...args) =>
  execFileSync(yarn, args, { cwd, stdio: "inherit" });
function verifyApp(cwd) {
  runYarn(cwd, "install");
  runYarn(cwd, "build");
  const appRequire = createRequire(join(cwd, "package.json"));
  const shellEntry = appRequire
    .resolve("@org/app-shell/styles.css")
    .replace(/styles\.css$/, "index.js");
  assert.ok(
    realpathSync(shellEntry).startsWith(join(cwd, "node_modules")),
    "Must use installed package, not a workspace source alias",
  );
  const shellRequire = createRequire(shellEntry);
  assert.equal(
    realpathSync(appRequire.resolve("react")),
    realpathSync(shellRequire.resolve("react")),
    "App and shell must resolve the same React runtime",
  );
  assert.ok(existsSync(join(cwd, "dist/index.html")));
}
for (const app of ["claims", "inventory", "onboarding"])
  verifyApp(resolve("examples", app));
const temp = mkdtempSync(join(tmpdir(), "org-packed-consumer-"));
try {
  execFileSync(
    "npm",
    [
      "install",
      "--prefix",
      join(temp, "cli"),
      resolve("artifacts/org-create-app-0.1.0.tgz"),
      "--ignore-scripts",
      "--no-audit",
      "--no-fund",
    ],
    { stdio: "inherit" },
  );
  const app = join(temp, "generated-app");
  execFileSync(
    process.execPath,
    [
      join(temp, "cli/node_modules/@org/create-app/bin/create-app.mjs"),
      app,
      "--packages-dir",
      resolve("artifacts"),
    ],
    { stdio: "inherit" },
  );
  verifyApp(app);
  const p = JSON.parse(readFileSync(join(app, "package.json")));
  assert.equal(p.name, "generated-app");
  console.log(
    "PASS: all three standalone examples plus a fresh app from the installed generator build successfully, with one React runtime per app.",
  );
} finally {
  rmSync(temp, { recursive: true, force: true });
}
