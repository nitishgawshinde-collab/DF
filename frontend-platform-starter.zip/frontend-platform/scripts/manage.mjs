import { execFileSync } from "node:child_process";
import { cpSync, mkdirSync, rmSync } from "node:fs";
import { resolve } from "node:path";
const packages = ["tooling", "ui", "app-shell", "create-app"];
const mode = process.argv[2];
if (mode === "build") {
  for (const name of ["ui", "app-shell"]) {
    rmSync(`packages/${name}/dist`, { recursive: true, force: true });
    execFileSync(
      process.execPath,
      [
        "node_modules/typescript/bin/tsc",
        "-p",
        `packages/${name}/tsconfig.json`,
      ],
      { stdio: "inherit" },
    );
    cpSync(
      `packages/${name}/src/styles.css`,
      `packages/${name}/dist/styles.css`,
    );
  }
} else if (mode === "pack") {
  mkdirSync("artifacts", { recursive: true });
  for (const name of packages)
    execFileSync("npm", ["pack", "--pack-destination", resolve("artifacts")], {
      cwd: `packages/${name}`,
      stdio: "inherit",
    });
} else throw new Error("Expected build or pack");
