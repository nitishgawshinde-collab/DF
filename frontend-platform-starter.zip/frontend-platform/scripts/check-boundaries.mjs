import { readdirSync, readFileSync } from "node:fs";
import { join } from "node:path";
const walk = (path) =>
  readdirSync(path, { withFileTypes: true }).flatMap((e) =>
    e.isDirectory() ? walk(join(path, e.name)) : [join(path, e.name)],
  );
for (const pkg of ["ui", "app-shell"]) {
  const manifest = JSON.parse(readFileSync(`packages/${pkg}/package.json`));
  const allowed = new Set([
    ...Object.keys(manifest.dependencies ?? {}),
    ...Object.keys(manifest.peerDependencies ?? {}),
  ]);
  for (const file of walk(`packages/${pkg}/src`).filter((f) =>
    /\.tsx?$/.test(f),
  )) {
    const source = readFileSync(file, "utf8");
    if (/claims|inventory|onboarding|examples\//i.test(source))
      throw new Error(`Business-specific code in ${file}`);
    for (const match of source.matchAll(
      /(?:from\s+|import\s*)['"]([^'"]+)['"]/g,
    )) {
      const spec = match[1];
      if (spec.startsWith(".")) {
        if (spec.includes("../.."))
          throw new Error(`Cross-package relative import: ${file}`);
        continue;
      }
      const name = spec.startsWith("@")
        ? spec.split("/").slice(0, 2).join("/")
        : spec.split("/")[0];
      if (!allowed.has(name))
        throw new Error(`Undeclared import ${name} in ${file}`);
    }
  }
}
console.log(
  "Shared source uses declared dependencies and contains no reference-application names.",
);
