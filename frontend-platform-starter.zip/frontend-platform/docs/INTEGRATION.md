# Integrate the real applications

No existing business source repositories were available. Use this sequence after providing repository access or source archives. Preserve each application's current business behavior and release pipeline.

## 1. Baseline and compatibility

For each app, record React/React DOM versions, Node/Yarn versions, framework/bundler, router, current CSS framework, auth provider, route guards, supported browsers, and key regression workflows. This package release requires React 19.3-compatible peers. Do not force-upgrade an older application just to install it; first validate its dependency compatibility or publish a platform version tested against the required React baseline.

Select the application with the least integration complexity as the first consumer. Save baseline screenshots and run its existing tests before changing layout.

## 2. Adopt the shell in app one

After configuring your private registry, install matching UI and shell packages. Use the published version approved for that application's React baseline. Import UI CSS first, shell CSS second, and application overrides last.

Place `AppShell` inside the existing auth/router/provider tree. Keep domain state and services in the application. Feed `activeId` from the current router location and render the existing route outlet as children. Supply branding and navigation in application configuration. Use the default landing initially. Avoid wrapping the shell around a second full header/sidebar layout.

Adapt global CSS carefully: shared component classes are prefixed, but typography within `.org-theme` is intentionally standardized. Check pre-existing tables, headings, form controls, and nested component libraries for style collisions.

Keep route authorization and server authorization in place. Hiding a navigation link is not permission enforcement.

## 3. Validate with app two

Use a different landing layout and theme. Reuse common UI where it fits. If customization requires `if (appName === ...)` inside a shared package, stop and introduce a generic slot/prop or keep the feature application-owned. Run both applications' regression suites against the same proposed platform release. Validate header/sidebar behavior, deep links, browser back, focus, errors, and narrow screens.

## 4. Adopt in app three

Proceed when the first two applications pass their own acceptance gates. Adopt the same public contracts, then release app three independently. It can retain its previous platform version during validation.

## Acceptance evidence needed from the real apps

- Existing critical business flows still work.
- Auth, route guards, direct navigation, reload, and browser back work.
- One React runtime is resolved; no invalid-hook warnings.
- Application-specific screens can be customized without domain conditions in platform code.
- Approved contrast, keyboard behavior, and mobile layout are preserved.
- Separate builds, rollbacks, and releases work in the organization's CI.

The included reference tests prove the foundation with sample workflows. They do not replace these application-specific gates.
