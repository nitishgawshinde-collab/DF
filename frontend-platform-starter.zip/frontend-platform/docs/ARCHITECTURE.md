# Architecture and customization

## Dependency direction

Applications import the shell and UI through package exports. The shell imports UI. UI imports React. Tooling supports builds; it is not shipped as application runtime code. The generator owns a starter template, not application business logic.

The platform has no knowledge of claims, inventory, onboarding, backend URLs, application IDs, or domain permissions. `scripts/check-boundaries.mjs` checks declared imports and rejects the three reference-domain names in shared runtime source. This is a useful guard, not a complete static architecture analyzer: code review must continue to enforce the boundary.

## Shell contract

```tsx
import { AppShell } from "@org/app-shell";
import "@org/ui/styles.css";
import "@org/app-shell/styles.css";

<AppShell
  branding={{ name: "My portal", subtitle: "Operations" }}
  navigation={[
    { id: "home", label: "Overview", href: "/" },
    { id: "work", label: "My work", href: "/work" },
  ]}
  activeId={currentRouteId}
  theme={{ accent: "#17654e", onAccent: "#ffffff" }}
  landing={{ title: "Welcome", description: "Start your next task." }}
  slots={{ headerActions: <UserMenu />, footer: <SupportLinks /> }}
>
  {currentRouteId === "home" ? undefined : <CurrentPage />}
</AppShell>;
```

`currentRouteId`, `UserMenu`, `SupportLinks`, and `CurrentPage` are supplied by the application; this is an integration sketch. Unique navigation IDs and stable hrefs are the application's responsibility.

Content precedence is `children` → `slots.landingPage` → configured default landing. Pass `undefined` or `null` for children when using a landing fallback. Supply a React element to `slots.landingPage`, not a component function. Supply an error callback through `onError` to connect approved telemetry; the shell does not log sensitive error details to users. The page boundary resets when `activeId` changes and offers a retry for render failures. Event-handler errors and async request failures remain application responsibilities.

Other slots: `sidebarFooter`, `footer`, `headerActions`. These support composition without introducing app-name conditionals. Navigation is a set of normal links. The shell does not install a router or intercept browser navigation. Reference applications demonstrate a small hash-routing adapter with browser back/forward and focus management. Keep your existing router in a real application; client-side router interception can be added deliberately as an API extension if required. Normal URL links work today but may trigger a full page navigation in a history-based app.

## Three landing patterns

- Configuration: set `landing.title`, `description`, and `links`.
- Replacement: set `slots.landingPage` to a custom dashboard.
- Composition: render `<DefaultLandingPage ...><ApplicationWidgets /></DefaultLandingPage>` in that slot.

A first-run onboarding experience is separate from the home-page fallback. No persistent first-login detection is included. Add it in the owning application using a server-backed completion preference when required.

## UI and accessibility

`TextField` binds labels, hints, and errors to generated stable IDs. Buttons use native button semantics and default to `type="button"`. Navigation identifies the active page. Mobile navigation exposes expanded state. The shell has a keyboard skip link and uses header, nav, aside, and main landmarks. Theme variables are scoped under `.org-theme`; app owners must preserve contrast when overriding colors. The mobile menu is an inline expansion, not a modal dialog.

The included browser checks verify basic keyboard behavior and mobile overflow. They are not a WCAG certification, full screen-reader audit, or cross-browser test suite.

## Policy and customization boundaries

Each app explicitly declares React and React DOM; `org-check` compares its package.json to the installed `@org/tooling` policy. Installing a shell package does not inherit a package.json or Yarn config. An application still owns its `.yarnrc.yml`, packageManager field, CI, and lockfile. The policy check validates declared versions; immutable installation uses the lockfile. Teams must bump their tooling package to receive a newer policy.

Runtime versions tested: Node 24, React/React DOM 19.3.0, Yarn 4.18.1, Vite 8.3.2, TypeScript 5.9.3. The initial starter is a client-rendered application. SSR/framework-specific support is not validated.

References consulted: https://yarnpkg.com/features/workspaces, https://yarnpkg.com/features/constraints, https://yarnpkg.com/configuration/manifest, https://vite.dev/guide/.
