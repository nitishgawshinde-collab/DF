# Registry and release procedure

Nothing in this delivery has been published to an external registry or deployed. `@org` is an example scope. Replace it consistently in package names, imports, generator manifests, policy references, tests, and archive filenames before the first organizational release if your real scope differs.

## Private registry configuration

For a Nexus npm registry, configure the scoped registry in the platform and consumer `.yarnrc.yml`. Replace the example URL with your actual repository endpoint:

```yaml
nodeLinker: node-modules
npmScopes:
  org:
    npmRegistryServer: "https://nexus.example.com/repository/npm-group/"
    npmPublishRegistry: "https://nexus.example.com/repository/npm-hosted/"
    npmAlwaysAuth: true
    npmAuthToken: "${NPM_TOKEN}"
```

Supply `NPM_TOKEN` using the organization's approved local credential mechanism and masked CI variables; never commit credentials. Use the registry's actual supported authentication method. The group endpoint reads packages, while publishing usually targets a hosted endpoint. Check these settings with your Nexus administrators.

## Initial publishing

1. Set the real scope and registry configuration.
2. Run immutable platform installation, `yarn verify`, `yarn verify:consumers`, and `yarn test:browser`.
3. Review packed contents in `artifacts/`. Packages contain built JavaScript, declarations, styles, or generator/tooling assets; they do not bundle React.
4. Publish from the relevant workspaces after approval under your release process:

```bash
yarn workspace @org/ui npm publish
yarn workspace @org/app-shell npm publish
yarn workspace @org/tooling npm publish
yarn workspace @org/create-app npm publish
```

The included GitLab CI verifies builds and tests. It has no automatic publishing or deployment job because registry endpoints, credentials, protected-tag policy, and deployment targets were not supplied.

## Subsequent releases

Initially release the platform package set together for a simple compatibility contract. Update package versions, shell UI peer compatibility, generator dependency versions, generator local archive naming, tests, and documentation as one reviewed change. The first version uses explicit constants; there is no automated version-bump CLI yet. Test the packed generator each time so template dependencies cannot silently lag behind the released packages.

Use patch versions for compatible fixes, minor versions for compatible additions once the API stabilizes, and major versions for breaking changes. Treat this 0.x API as provisional and communicate compatibility explicitly. Do not replace an existing registry version. Publish a new version and create consumer update PRs. Each consumer commits its own lockfile and releases independently.

When upgrading React, update the UI/shell peer ranges, package development versions, tooling policy, and generator manifests together, then validate every reference consumer and each real application's regression suite. A policy package update checks alignment; it does not rewrite app manifests.

For rollback, revert the consumer dependency/lockfile change and redeploy that application's prior build. There is no remotely mutable shared runtime in this design.
