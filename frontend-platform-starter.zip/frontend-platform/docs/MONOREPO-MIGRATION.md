# Future monorepo migration

The reference examples deliberately use standalone projects today. Keep them independent while validating the separate-repository release model.

When organizational ownership and access requirements permit consolidation:

1. Move application source into `apps/<name>` alongside the existing `packages/*`.
2. Expand the root workspace list to `packages/*` and `apps/*`.
3. Change internal @org dependencies from registry versions to `workspace:^`. Remove archive file dependencies from migrated apps.
4. Remove application lockfiles only as part of this reviewed migration, install at the root, and commit one new root lockfile. Consolidate compatible package manager and Yarn settings.
5. Keep React/React DOM explicitly declared by each application. Add Yarn constraints to enforce approved versions across workspaces, and align framework compatibility before changing them.
6. Build UI before shell and shell before applications. Do not substitute application-specific imports for package public APIs.
7. Keep each application's build output and environment configuration separate. Run shared-package changes against all affected consumers.
8. Decide whether releases share a version, a release window, or an atomic deployment. A monorepo by itself imposes none of these. Keep rollback strategy explicit.

The current shell, UI, and generator APIs can remain stable during the move. Switching dependency transport does not require rewriting business screens. This migration is documented, not performed against real repositories in this delivery.
