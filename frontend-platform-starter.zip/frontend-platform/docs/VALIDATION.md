# Validation report

Validated on October 4, 2026 in the execution environment.

## Completed

- Platform dependency installation with `--immutable`: passed.
- Shared source boundary and declared-import checks: passed.
- UI and shell TypeScript compilation/declaration output: passed.
- Generator and dependency-policy tests: 3 passed.
- All four packages packed successfully with their required runtime/template files.
- Claims, inventory, and onboarding independently installed the packed packages and passed policy checks, TypeScript checking, and production builds.
- The packed generator was installed into a temporary directory; a fourth application was created outside the platform repository, independently installed, and production-built successfully.
- Each consumer used installed package files and resolved the same React runtime from its app and shell.
- Browser suite: 28 checks passed with no uncaught browser errors.
- Desktop and mobile screenshots generated; inventory desktop and onboarding mobile visually inspected.

## Browser checks

- Claims renders configured default landing
- Claims filter narrows data
- Claims approval updates application state
- Claims empty state
- Browser back restores landing
- Inventory replaces landing via slot
- Inventory theme override
- Inventory validates blank quantity
- Inventory receives stock
- Onboarding composes default landing with custom content
- Onboarding validates empty profile
- Onboarding progress reflects all three steps
- Onboarding progress reverses correctly
- Sample state resets as documented
- Keyboard skip link is first focus target
- Skip link focuses main content
- Skip link preserves current route content
- claims: mobile navigation opens
- claims: mobile navigation closes after selection
- claims: no mobile page overflow
- inventory: mobile navigation opens
- inventory: mobile navigation closes after selection
- inventory: no mobile page overflow
- onboarding: mobile navigation opens
- onboarding: mobile navigation closes after selection
- onboarding: no mobile page overflow
- Application-owned unknown-route handling
- No browser errors: 

## Environment and limitations

Node 24.19.0, Yarn 4.18.1, React/React DOM 19.3.0, TypeScript 5.9.3, Vite 8.3.2, and Playwright 1.58.2 were used. The standard Playwright browser download failed in this environment; tests used an explicitly supplied Chromium 153 executable instead. Other browsers were not tested. CI uses the normal Playwright browser installation and has not been executed in your GitLab environment.

No real application repositories, private registry endpoint, or production credentials were supplied. Real application integration, private-registry publishing, authentication, backend integration, production deployment, and organization-specific acceptance tests remain pending. Examples demonstrate in-memory interactions; no server or durable business data is included. The page error boundary is implemented but the browser suite does not inject a deliberate render failure. No complete accessibility, security, performance, or SSR certification is claimed.

The download includes source, lockfiles, built packages, package archives, reference app builds, setup/release/migration guides, screenshots, and the machine-readable browser report. Third-party dependencies and browser binaries are excluded. An initial dependency installation requires registry access.
