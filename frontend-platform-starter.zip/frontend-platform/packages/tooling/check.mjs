#!/usr/bin/env node
import { readFileSync } from "node:fs";
const policy = JSON.parse(
  readFileSync(new URL("./policy.json", import.meta.url)),
);
const app = JSON.parse(readFileSync("package.json", "utf8"));
const errors = [];
for (const field of ["dependencies", "devDependencies", "engines"]) {
  for (const [name, expected] of Object.entries(policy[field])) {
    if (app[field]?.[name] !== expected)
      errors.push(`${field}.${name}: expected ${expected}`);
  }
}
if (app.packageManager !== policy.packageManager)
  errors.push(`packageManager: expected ${policy.packageManager}`);
if (errors.length) {
  console.error(errors.join("\n"));
  process.exitCode = 1;
} else console.log("Application matches the installed platform policy.");
