import {
  Component,
  useId,
  useState,
  type CSSProperties,
  type ErrorInfo,
  type ReactNode,
} from "react";
import { Button, Card, PageHeading } from "@org/ui";
export interface NavigationItem {
  id: string;
  label: string;
  href: string;
}
export interface Theme {
  accent?: string;
  onAccent?: string;
  background?: string;
  radius?: string;
}
export interface LandingPageProps {
  title: string;
  description?: string;
  links?: readonly { label: string; href: string; description?: string }[];
  children?: ReactNode;
}
export function DefaultLandingPage({
  title,
  description,
  links = [],
  children,
}: LandingPageProps) {
  return (
    <div className="org-stack">
      <PageHeading
        eyebrow="Your workspace"
        title={title}
        description={description}
      />
      {links.length > 0 && (
        <div className="org-grid">
          {links.map((link) => (
            <Card key={link.href}>
              <h2>
                <a href={link.href}>{link.label}</a>
              </h2>
              {link.description && (
                <p className="org-muted">{link.description}</p>
              )}
            </Card>
          ))}
        </div>
      )}
      {children}
    </div>
  );
}
class PageBoundary extends Component<
  { children: ReactNode; onError?: (error: Error, info: ErrorInfo) => void },
  { failed: boolean }
> {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  componentDidCatch(error: Error, info: ErrorInfo) {
    this.props.onError?.(error, info);
  }
  render() {
    return this.state.failed ? (
      <Card title="This page could not load">
        <p>
          Please try again. If the problem continues, contact your support team.
        </p>
        <Button onClick={() => this.setState({ failed: false })}>
          Try again
        </Button>
      </Card>
    ) : (
      this.props.children
    );
  }
}
export interface AppShellProps {
  branding: { name: string; subtitle?: string; logo?: ReactNode };
  navigation: readonly NavigationItem[];
  activeId: string;
  theme?: Theme;
  landing?: LandingPageProps;
  children?: ReactNode;
  slots?: {
    landingPage?: ReactNode;
    headerActions?: ReactNode;
    sidebarFooter?: ReactNode;
    footer?: ReactNode;
  };
  onError?: (error: Error, info: ErrorInfo) => void;
}
export function AppShell({
  branding,
  navigation,
  activeId,
  theme,
  landing,
  slots,
  children,
  onError,
}: AppShellProps) {
  const [menuOpen, setMenuOpen] = useState(false);
  const navId = useId();
  const mainId = useId();
  const style = {
    "--org-accent": theme?.accent,
    "--org-on-accent": theme?.onAccent,
    "--org-bg": theme?.background,
    "--org-radius": theme?.radius,
  } as CSSProperties;
  return (
    <div className="org-theme org-shell" style={style}>
      <a className="org-skip" href={`#${mainId}`}>
        Skip to content
      </a>
      <header className="org-topbar">
        <div className="org-brand">
          {branding.logo ?? (
            <span aria-hidden="true" className="org-mark">
              {branding.name.slice(0, 1)}
            </span>
          )}
          <div>
            <strong>{branding.name}</strong>
            {branding.subtitle && <small>{branding.subtitle}</small>}
          </div>
        </div>
        <div className="org-header-actions">
          {slots?.headerActions}
          <button
            className="org-menu org-button org-button--secondary"
            aria-expanded={menuOpen}
            aria-controls={navId}
            onClick={() => setMenuOpen(!menuOpen)}
          >
            Menu
          </button>
        </div>
      </header>
      <aside className={`org-sidebar ${menuOpen ? "org-sidebar--open" : ""}`}>
        <nav id={navId} aria-label="Main navigation">
          <p className="org-eyebrow">Workspace</p>
          {navigation.map((item) => (
            <a
              key={item.id}
              href={item.href}
              aria-current={activeId === item.id ? "page" : undefined}
              onClick={() => setMenuOpen(false)}
            >
              {item.label}
            </a>
          ))}
        </nav>
        <div className="org-sidebar-footer">{slots?.sidebarFooter}</div>
      </aside>
      <main id={mainId} tabIndex={-1} className="org-main">
        <PageBoundary key={activeId} onError={onError}>
          {children ?? slots?.landingPage ?? (
            <DefaultLandingPage
              {...(landing ?? { title: `Welcome to ${branding.name}` })}
            />
          )}
        </PageBoundary>
        {slots?.footer && (
          <footer className="org-footer">{slots.footer}</footer>
        )}
      </main>
    </div>
  );
}
