import {
  useId,
  type ButtonHTMLAttributes,
  type HTMLAttributes,
  type InputHTMLAttributes,
  type ReactNode,
} from "react";
export function Button({
  variant = "primary",
  className = "",
  type = "button",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "secondary";
}) {
  return (
    <button
      {...props}
      type={type}
      className={`org-button org-button--${variant} ${className}`}
    />
  );
}
export function Card({
  title,
  children,
  className = "",
  ...props
}: Omit<HTMLAttributes<HTMLElement>, "title"> & { title?: string }) {
  const id = useId();
  return (
    <section
      {...props}
      aria-labelledby={title ? id : undefined}
      className={`org-card ${className}`}
    >
      {title && <h2 id={id}>{title}</h2>}
      {children}
    </section>
  );
}
export function Badge({
  children,
  tone = "neutral",
}: {
  children: ReactNode;
  tone?: "neutral" | "success" | "warning";
}) {
  return <span className={`org-badge org-badge--${tone}`}>{children}</span>;
}
export function TextField({
  label,
  hint,
  error,
  id,
  className = "",
  ...props
}: InputHTMLAttributes<HTMLInputElement> & {
  label: string;
  hint?: string;
  error?: string;
}) {
  const generated = useId();
  const fieldId = id ?? generated;
  const descriptions =
    [
      props["aria-describedby"],
      hint && `${fieldId}-hint`,
      error && `${fieldId}-error`,
    ]
      .filter(Boolean)
      .join(" ") || undefined;
  return (
    <div className="org-field">
      <label htmlFor={fieldId}>{label}</label>
      <input
        {...props}
        id={fieldId}
        aria-invalid={error ? true : props["aria-invalid"]}
        aria-describedby={descriptions}
        className={`org-input ${className}`}
      />
      {hint && <small id={`${fieldId}-hint`}>{hint}</small>}
      {error && (
        <span className="org-error" id={`${fieldId}-error`} role="alert">
          {error}
        </span>
      )}
    </div>
  );
}
export function PageHeading({
  eyebrow,
  title,
  description,
  action,
}: {
  eyebrow?: string;
  title: string;
  description?: string;
  action?: ReactNode;
}) {
  return (
    <div className="org-heading">
      <div>
        {eyebrow && <p className="org-eyebrow">{eyebrow}</p>}
        <h1>{title}</h1>
        {description && <p className="org-muted">{description}</p>}
      </div>
      {action}
    </div>
  );
}
