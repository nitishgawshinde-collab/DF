import { AppShell } from "@org/app-shell";
import { Card, PageHeading } from "@org/ui";
import { usePage } from "./usePage";
export function App() {
  const page = usePage();
  return (
    <AppShell
      branding={{ name: "__APP_TITLE__", subtitle: "Team workspace" }}
      navigation={[
        { id: "home", label: "Overview", href: "#/" },
        { id: "work", label: "My work", href: "#/work" },
      ]}
      activeId={page}
      landing={{
        title: "Welcome to __APP_TITLE__",
        description:
          "Your workspace is ready. Add your business pages when you are ready.",
        links: [
          {
            label: "My work",
            href: "#/work",
            description: "Open your team workspace.",
          },
        ],
      }}
    >
      {page === "home" ? undefined : page === "work" ? (
        <>
          <PageHeading title="My work" />
          <Card title="Ready for your workflow">
            <p>Add application-specific functionality here.</p>
          </Card>
        </>
      ) : (
        <>
          <PageHeading title="Page not found" />
          <a href="#/">Return to overview</a>
        </>
      )}
    </AppShell>
  );
}
