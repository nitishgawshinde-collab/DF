import test from "node:test";
import assert from "node:assert/strict";
import {
  mkdtempSync,
  readFileSync,
  readdirSync,
  rmSync,
  writeFileSync,
} from "node:fs";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { spawnSync } from "node:child_process";
const bin = resolve("packages/create-app/bin/create-app.mjs");
const run = (...args) =>
  spawnSync(process.execPath, [bin, ...args], { encoding: "utf8" });
test("creates an independent app with registry packages and matching policy", () => {
  const dir = mkdtempSync(join(tmpdir(), "org-generator-"));
  try {
    const target = join(dir, "sample-app");
    assert.equal(run(target).status, 0);
    const p = JSON.parse(readFileSync(join(target, "package.json")));
    assert.equal(p.name, "sample-app");
    assert.equal(p.dependencies["@org/app-shell"], "0.1.0");
    assert.equal(p.workspaces, undefined);
    assert.ok(readdirSync(target).includes(".yarnrc.yml"));
    const policy = JSON.parse(readFileSync("packages/tooling/policy.json"));
    for (const f of ["dependencies", "devDependencies", "engines"])
      for (const [k, v] of Object.entries(policy[f])) assert.equal(p[f][k], v);
    assert.equal(p.packageManager, policy.packageManager);
    assert.match(
      readFileSync(join(target, "src/App.tsx"), "utf8"),
      /Sample App/,
    );
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});
test("rejects invalid names, unknown options, missing archives, and nonempty destinations before writing", () => {
  const dir = mkdtempSync(join(tmpdir(), "org-generator-"));
  try {
    const target = join(dir, "sample");
    for (const args of [
      ["--name", "../../bad"],
      ["--wat", "x"],
      ["--name"],
      ["--packages-dir", join(dir, "missing")],
    ])
      assert.notEqual(run(target, ...args).status, 0);
    assert.deepEqual(readdirSync(dir), []);
    writeFileSync(join(dir, "keep.txt"), "keep");
    assert.notEqual(run(dir, "--name", "sample").status, 0);
    assert.equal(readFileSync(join(dir, "keep.txt"), "utf8"), "keep");
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});
test("policy rejects dependency drift in a consumer", () => {
  const dir = mkdtempSync(join(tmpdir(), "org-policy-"));
  try {
    const target = join(dir, "sample");
    assert.equal(run(target).status, 0);
    const checker = resolve("packages/tooling/check.mjs");
    assert.equal(
      spawnSync(process.execPath, [checker], { cwd: target }).status,
      0,
    );
    const path = join(target, "package.json");
    const p = JSON.parse(readFileSync(path));
    p.dependencies.react = "18.0.0";
    writeFileSync(path, JSON.stringify(p));
    const result = spawnSync(process.execPath, [checker], {
      cwd: target,
      encoding: "utf8",
    });
    assert.notEqual(result.status, 0);
    assert.match(result.stderr, /dependencies.react/);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});
