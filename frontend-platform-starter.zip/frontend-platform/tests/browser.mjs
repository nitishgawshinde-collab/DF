import { chromium } from "playwright";
import { spawn } from "node:child_process";
import { mkdirSync, writeFileSync } from "node:fs";
import { resolve } from "node:path";
import assert from "node:assert/strict";
const servers = [];
let browser;
const passed = [];
const consoleErrors = [];
const check = (condition, label) => {
  assert.ok(condition, label);
  passed.push(label);
};
const waitForServer = async (url) => {
  for (let i = 0; i < 100; i++) {
    try {
      if ((await fetch(url)).ok) return;
    } catch {}
    await new Promise((r) => setTimeout(r, 100));
  }
  throw Error(`Server unavailable: ${url}`);
};
mkdirSync(".test-output", { recursive: true });
try {
  for (const [i, name] of ["claims", "inventory", "onboarding"].entries()) {
    const server = spawn(
      process.execPath,
      [
        "node_modules/vite/bin/vite.js",
        "preview",
        "--host",
        "127.0.0.1",
        "--port",
        String(4310 + i),
        "--strictPort",
      ],
      { cwd: resolve(`examples/${name}`), stdio: "pipe" },
    );
    servers.push(server);
    await waitForServer(`http://127.0.0.1:${4310 + i}`);
  }
  browser = await chromium.launch({
    headless: true,
    executablePath: process.env.CHROMIUM_EXECUTABLE_PATH || undefined,
    args: ["--no-sandbox", "--disable-dev-shm-usage"],
  });
  const page = await browser.newPage({
    viewport: { width: 1440, height: 1000 },
  });
  page.on("pageerror", (e) => consoleErrors.push(e.message));
  page.on("console", (m) => {
    if (m.type() === "error") consoleErrors.push(m.text());
  });
  await page.goto("http://127.0.0.1:4310");
  await page.getByRole("heading", { name: "Good work starts here." }).waitFor();
  passed.push("Claims renders configured default landing");
  await page.screenshot({
    path: ".test-output/claims-desktop.png",
    fullPage: true,
  });
  await page.getByRole("link", { name: "Open claims queue" }).click();
  await page.getByRole("heading", { name: "Claims queue" }).waitFor();
  await page.getByLabel("Search claims").fill("Avery");
  check(
    (await page.locator("tbody tr").count()) === 1,
    "Claims filter narrows data",
  );
  await page.getByRole("button", { name: "Approve CL-1042" }).click();
  check(
    await page.getByRole("button", { name: "Approve CL-1042" }).isDisabled(),
    "Claims approval updates application state",
  );
  await page.getByLabel("Search claims").fill("missing");
  await page
    .getByRole("status")
    .filter({ hasText: "No matching claims." })
    .waitFor();
  passed.push("Claims empty state");
  await page.goBack();
  await page.getByRole("heading", { name: "Good work starts here." }).waitFor();
  passed.push("Browser back restores landing");
  await page.goto("http://127.0.0.1:4311");
  await page
    .getByRole("heading", { name: "Keep everything moving." })
    .waitFor();
  passed.push("Inventory replaces landing via slot");
  check(
    (await page
      .locator(".org-shell")
      .evaluate((el) =>
        getComputedStyle(el).getPropertyValue("--org-accent").trim(),
      )) === "#17654e",
    "Inventory theme override",
  );
  await page.screenshot({
    path: ".test-output/inventory-desktop.png",
    fullPage: true,
  });
  await page.getByRole("link", { name: "Stock room", exact: true }).click();
  await page.getByRole("button", { name: "Receive stock" }).click();
  await page.getByRole("alert").waitFor();
  passed.push("Inventory validates blank quantity");
  await page.getByLabel("Units received").fill("8");
  await page.getByRole("button", { name: "Receive stock" }).click();
  check(
    (await page.getByTestId("quantity").textContent()) === "12",
    "Inventory receives stock",
  );
  await page
    .getByRole("status")
    .filter({ hasText: "8 units received." })
    .waitFor();
  await page.goto("http://127.0.0.1:4312");
  await page
    .getByRole("heading", { name: "Make your first day count." })
    .waitFor();
  await page.getByRole("heading", { name: "A note from your team" }).waitFor();
  passed.push("Onboarding composes default landing with custom content");
  await page.screenshot({
    path: ".test-output/onboarding-desktop.png",
    fullPage: true,
  });
  await page
    .getByRole("navigation")
    .getByRole("link", { name: "Your checklist" })
    .click();
  await page.getByRole("button", { name: "Save profile" }).click();
  await page.getByRole("alert").waitFor();
  passed.push("Onboarding validates empty profile");
  await page.getByLabel("Display name").fill("Alex");
  await page.getByRole("button", { name: "Save profile" }).click();
  await page.getByRole("checkbox", { name: "Read the handbook" }).check();
  await page.getByRole("checkbox", { name: "Meet your manager" }).check();
  check(
    (await page.getByRole("progressbar").getAttribute("value")) === "3",
    "Onboarding progress reflects all three steps",
  );
  await page.getByRole("checkbox", { name: "Meet your manager" }).uncheck();
  check(
    (await page.getByRole("progressbar").getAttribute("value")) === "2",
    "Onboarding progress reverses correctly",
  );
  await page.reload();
  check(
    (await page.getByRole("progressbar").getAttribute("value")) === "0",
    "Sample state resets as documented",
  );
  await page.keyboard.press("Tab");
  check(
    (await page.evaluate(() => document.activeElement?.textContent)) ===
      "Skip to content",
    "Keyboard skip link is first focus target",
  );
  await page.keyboard.press("Enter");
  check(
    (await page.evaluate(() => document.activeElement?.tagName)) === "MAIN",
    "Skip link focuses main content",
  );
  await page.getByRole("heading", { name: "Your checklist" }).waitFor();
  passed.push("Skip link preserves current route content");
  for (const [i, name] of ["claims", "inventory", "onboarding"].entries()) {
    await page.setViewportSize({ width: 390, height: 844 });
    await page.goto(`http://127.0.0.1:${4310 + i}`);
    const menu = page.getByRole("button", { name: "Menu", exact: true });
    await menu.waitFor();
    await menu.click();
    check(
      (await menu.getAttribute("aria-expanded")) === "true",
      `${name}: mobile navigation opens`,
    );
    await page.getByRole("navigation").getByRole("link").nth(1).click();
    await page
      .getByRole("heading", {
        name: ["Claims queue", "Stock room", "Your checklist"][i],
        exact: true,
      })
      .waitFor();
    check(
      (await menu.getAttribute("aria-expanded")) === "false",
      `${name}: mobile navigation closes after selection`,
    );
    check(
      await page.evaluate(
        () => document.documentElement.scrollWidth <= innerWidth,
      ),
      `${name}: no mobile page overflow`,
    );
    await page.screenshot({
      path: `.test-output/${name}-mobile.png`,
      fullPage: true,
    });
  }
  await page.goto("http://127.0.0.1:4310/#/unknown");
  await page.getByRole("heading", { name: "Page not found" }).waitFor();
  passed.push("Application-owned unknown-route handling");
  check(
    consoleErrors.length === 0,
    `No browser errors: ${consoleErrors.join("; ")}`,
  );
  writeFileSync(
    ".test-output/browser-results.json",
    JSON.stringify({ passed, consoleErrors }, null, 2),
  );
  console.log(`${passed.length} browser checks passed.`);
} finally {
  await browser?.close();
  for (const server of servers) server.kill();
}
