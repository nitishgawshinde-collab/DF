import { useState } from "react";
import { AppShell, DefaultLandingPage } from "@org/app-shell";
import { Badge, Button, Card, PageHeading, TextField } from "@org/ui";
import { usePage } from "./usePage";
function Welcome() {
  return (
    <DefaultLandingPage
      title="Make your first day count."
      description="Everything you need for a confident start, in one place."
      links={[
        {
          label: "Your checklist",
          href: "#/checklist",
          description: "Work through your three onboarding steps.",
        },
      ]}
    >
      <Card title="A note from your team">
        <p>
          Welcome aboard. Start with your profile, explore the team handbook,
          and schedule a conversation with your manager.
        </p>
        <Badge tone="success">Your workspace is ready</Badge>
      </Card>
    </DefaultLandingPage>
  );
}
function Checklist() {
  const [name, setName] = useState("");
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState("");
  const [done, setDone] = useState<string[]>([]);
  const count = Number(saved) + done.length;
  return (
    <div className="org-stack">
      <PageHeading
        title="Your checklist"
        description="Complete each step at your own pace."
      />
      <Card title="Progress">
        <label htmlFor="progress">{count} of 3 steps complete</label>
        <progress id="progress" value={count} max={3} />
      </Card>
      <Card title="1. Introduce yourself">
        <form
          className="org-stack"
          onSubmit={(e) => {
            e.preventDefault();
            if (!name.trim()) {
              setError("Enter your display name.");
              return;
            }
            setError("");
            setSaved(true);
          }}
        >
          <TextField
            label="Display name"
            value={name}
            error={error}
            onChange={(e) => {
              setName(e.target.value);
              setSaved(false);
            }}
          />
          <div>
            <Button type="submit">Save profile</Button>
          </div>
          <p role="status">{saved ? `Profile saved for ${name}.` : ""}</p>
        </form>
      </Card>
      {["Read the handbook", "Meet your manager"].map((item, i) => (
        <Card title={`${i + 2}. ${item}`} key={item}>
          <label className="org-row">
            <span>Mark this step complete</span>
            <input
              type="checkbox"
              aria-label={item}
              checked={done.includes(item)}
              onChange={(e) =>
                setDone(
                  e.target.checked
                    ? [...done, item]
                    : done.filter((x) => x !== item),
                )
              }
            />
          </label>
        </Card>
      ))}
    </div>
  );
}
export function App() {
  const page = usePage();
  return (
    <AppShell
      branding={{ name: "People welcome", subtitle: "Your new beginning" }}
      theme={{ accent: "#713cb5", background: "#f8f5fc", radius: "18px" }}
      activeId={page}
      navigation={[
        { id: "home", label: "Welcome", href: "#/" },
        { id: "checklist", label: "Your checklist", href: "#/checklist" },
      ]}
      slots={{
        landingPage: <Welcome />,
        headerActions: <Badge>New starter</Badge>,
        sidebarFooter: "Reference application 03",
        footer:
          "Reference onboarding · no personal information is sent or retained",
      }}
    >
      {page === "home" ? undefined : page === "checklist" ? (
        <Checklist />
      ) : (
        <PageHeading title="Page not found" />
      )}
    </AppShell>
  );
}
