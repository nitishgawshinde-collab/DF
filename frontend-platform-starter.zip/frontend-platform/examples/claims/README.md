# Generated application

Use Node 24. Run `corepack enable`, `yarn install`, and `yarn dev`.
Run `yarn build` to check policy, type-check, and produce `dist/`.
Commit yarn.lock before CI runs `yarn install --immutable`.

Configure the @org registry in .yarnrc.yml before installation when using published packages.
For local validation, generate using --packages-dir with the packed platform archives.
Change src/App.tsx to set branding, navigation, theme, and landing content.
The example uses hash URLs; production routing remains application-owned.
No authentication or backend is supplied. This starter is a frontend foundation.
