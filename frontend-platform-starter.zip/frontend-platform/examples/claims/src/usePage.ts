import { useEffect, useState } from "react";
// Example routing adapter, owned by the application. Replace with your router as needed.
const readPage = () =>
  window.location.hash.startsWith("#/")
    ? window.location.hash.slice(2) || "home"
    : "home";
export function usePage() {
  const [page, setPage] = useState(readPage);
  useEffect(() => {
    const change = () => {
      // Ignore the shell's skip-link fragment, which is not an application route.
      if (window.location.hash && !window.location.hash.startsWith("#/"))
        return;
      setPage(readPage());
      requestAnimationFrame(() =>
        document.querySelector<HTMLElement>("main")?.focus(),
      );
    };
    window.addEventListener("hashchange", change);
    return () => window.removeEventListener("hashchange", change);
  }, []);
  return page;
}
