import { useState } from "react";
import { AppShell } from "@org/app-shell";
import { Badge, Button, Card, PageHeading, TextField } from "@org/ui";
import { usePage } from "./usePage";
const seed = [
  { id: "CL-1042", customer: "Avery Morgan", status: "In review" },
  { id: "CL-1043", customer: "Jordan Lee", status: "New" },
  { id: "CL-1044", customer: "Sam Rivera", status: "Approved" },
];
function Claims() {
  const [query, setQuery] = useState("");
  const [rows, setRows] = useState(seed);
  const filtered = rows.filter((r) =>
    `${r.id} ${r.customer}`.toLowerCase().includes(query.toLowerCase()),
  );
  return (
    <div className="org-stack">
      <PageHeading
        eyebrow="Operations"
        title="Claims queue"
        description="Review and resolve the claims assigned to your team."
      />
      <Card>
        <TextField
          label="Search claims"
          placeholder="Claim ID or customer"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <div className="org-scroll">
          <table>
            <caption className="org-muted">
              Sample claims · changes last until you leave this page
            </caption>
            <thead>
              <tr>
                <th>Claim</th>
                <th>Customer</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((row) => (
                <tr key={row.id}>
                  <td>{row.id}</td>
                  <td>{row.customer}</td>
                  <td>
                    <Badge
                      tone={row.status === "Approved" ? "success" : "warning"}
                    >
                      {row.status}
                    </Badge>
                  </td>
                  <td>
                    <Button
                      variant="secondary"
                      disabled={row.status === "Approved"}
                      aria-label={`Approve ${row.id}`}
                      onClick={() =>
                        setRows(
                          rows.map((r) =>
                            r.id === row.id ? { ...r, status: "Approved" } : r,
                          ),
                        )
                      }
                    >
                      {row.status === "Approved" ? "Approved" : "Approve"}
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {!filtered.length && <p role="status">No matching claims.</p>}
      </Card>
    </div>
  );
}
export function App() {
  const page = usePage();
  return (
    <AppShell
      branding={{ name: "Claims desk", subtitle: "Service operations" }}
      activeId={page}
      navigation={[
        { id: "home", label: "Overview", href: "#/" },
        { id: "claims", label: "Claims queue", href: "#/claims" },
      ]}
      landing={{
        title: "Good work starts here.",
        description:
          "A focused workspace for your next claim, review, and decision.",
        links: [
          {
            label: "Open claims queue",
            description: "Review incoming requests and make the next decision.",
            href: "#/claims",
          },
        ],
      }}
      slots={{
        headerActions: <Badge>Reference application 01</Badge>,
        sidebarFooter: (
          <>
            Claims operations
            <br />
            Independent application
          </>
        ),
        footer: "Demonstration data · no backend connection",
      }}
    >
      {page === "home" ? undefined : page === "claims" ? (
        <Claims />
      ) : (
        <PageHeading title="Page not found" />
      )}
    </AppShell>
  );
}
