import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "@org/ui/styles.css";
import "@org/app-shell/styles.css";
import { App } from "./App";
createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
