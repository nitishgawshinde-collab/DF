import { useState } from "react";
import { AppShell } from "@org/app-shell";
import { Badge, Button, Card, PageHeading, TextField } from "@org/ui";
import { usePage } from "./usePage";
function InventoryHome() {
  return (
    <div className="org-stack">
      <PageHeading
        eyebrow="Supply & logistics"
        title="Keep everything moving."
        description="Track available stock and prepare for your next delivery."
        action={<a href="#/stock">Manage stock →</a>}
      />
      <div className="org-grid">
        <Card title="Active products">
          <p className="org-stat">1</p>
          <p className="org-muted">Sample catalog</p>
        </Card>
        <Card title="Needs attention">
          <p className="org-stat">1</p>
          <Badge tone="warning">Below reorder level</Badge>
        </Card>
        <Card title="Warehouse">
          <p className="org-stat">Pune</p>
          <p className="org-muted">Primary distribution center</p>
        </Card>
      </div>
      <Card title="Ready for the next delivery">
        <p>
          Packing cartons are below the reorder level. Receive new stock to keep
          your warehouse ready.
        </p>
        <a href="#/stock">View current stock</a>
      </Card>
    </div>
  );
}
function Stock() {
  const [quantity, setQuantity] = useState(4);
  const [amount, setAmount] = useState("");
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  return (
    <div className="org-stack">
      <PageHeading
        title="Stock room"
        description="Receive units against the sample catalog."
      />
      <Card title="Packing cartons">
        <p>
          Available quantity: <strong data-testid="quantity">{quantity}</strong>
        </p>
        <Badge tone={quantity < 10 ? "warning" : "success"}>
          {quantity < 10 ? "Low stock" : "In stock"}
        </Badge>
        <form
          style={{ marginTop: 20, display: "grid", gap: 16, maxWidth: 360 }}
          onSubmit={(e) => {
            e.preventDefault();
            const n = Number(amount);
            if (!Number.isInteger(n) || n < 1 || n > 10000) {
              setError("Enter a whole number from 1 to 10000.");
              setMessage("");
              return;
            }
            setQuantity(quantity + n);
            setAmount("");
            setError("");
            setMessage(`${n} units received.`);
          }}
        >
          <TextField
            label="Units received"
            inputMode="numeric"
            value={amount}
            error={error}
            onChange={(e) => setAmount(e.target.value)}
          />
          <Button type="submit">Receive stock</Button>
          <p role="status">{message}</p>
        </form>
      </Card>
    </div>
  );
}
export function App() {
  const page = usePage();
  return (
    <AppShell
      branding={{ name: "Inventory studio", subtitle: "Supply operations" }}
      activeId={page}
      theme={{ accent: "#17654e", background: "#f2f7f4" }}
      navigation={[
        { id: "home", label: "Overview", href: "#/" },
        { id: "stock", label: "Stock room", href: "#/stock" },
      ]}
      slots={{
        landingPage: <InventoryHome />,
        headerActions: <Badge tone="success">Pune warehouse</Badge>,
        sidebarFooter: "Reference application 02",
        footer: "Sample inventory · changes reset when leaving the page",
      }}
    >
      {page === "home" ? undefined : page === "stock" ? (
        <Stock />
      ) : (
        <PageHeading title="Page not found" />
      )}
    </AppShell>
  );
}
