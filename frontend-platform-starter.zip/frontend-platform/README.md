# Shared React frontend platform

A working first increment: a reusable shell, a small UI package, shared TypeScript and dependency policy, and an application generator. Includes three independently installed reference consumers. **Your existing business repositories were not supplied or modified.** These examples validate the architecture; they do not represent completed integration into your real applications.

## Start here

Prerequisites: Node 24 and Corepack. If your Node installation does not include Corepack, install it through your organization's approved tooling process. Internet access to the npm registry is needed on first installation.

```bash
corepack enable
cd frontend-platform
yarn install --immutable
yarn verify
yarn verify:consumers
cd examples/claims
yarn dev
```

Open the URL printed by Vite. Run `yarn dev` from `examples/inventory` or `examples/onboarding` to explore the other apps. Vite chooses an available development port.

`yarn verify` checks source boundaries, builds the UI and shell, runs generator/policy tests, and creates four package archives in `artifacts/`. `yarn verify:consumers` installs and builds the three standalone examples, installs the **packed generator** into a temporary directory, generates a fourth fresh application outside the repository, and builds it. It also checks that each consumer resolves one React runtime and uses installed package files.

For browser validation:

```bash
yarn exec playwright install chromium
yarn test:browser
```

On Linux CI, use `yarn exec playwright install --with-deps chromium`. If a Chromium binary is already installed, set `CHROMIUM_EXECUTABLE_PATH` instead. Browser tests start and stop preview servers on ports 4310–4312. Screenshots and machine-readable results go to `.test-output/`.

## Packages

| Package           | Main files                                                   | Purpose                                                                                       |
| ----------------- | ------------------------------------------------------------ | --------------------------------------------------------------------------------------------- |
| `@org/ui`         | `packages/ui/src/index.tsx`, `styles.css`                    | Button, Card, Badge, TextField, PageHeading; scoped styles and theme tokens                   |
| `@org/app-shell`  | `packages/app-shell/src/index.tsx`, `styles.css`             | Responsive header/sidebar, navigation, default landing, slots, skip link, page error boundary |
| `@org/tooling`    | `packages/tooling/tsconfig.json`, `policy.json`, `check.mjs` | Strict TypeScript baseline and an executable dependency-policy check                          |
| `@org/create-app` | `packages/create-app/bin/create-app.mjs`, `template/`        | Safe standalone generator with registry and local-archive modes                               |

Only `packages/*` are platform workspaces. **The examples are separate Yarn projects**, each with its own manifest and lockfile. They consume real `.tgz` archives, without source aliases or workspace links. Their placement in this download is for convenience, not shared release ownership.

The packages use ESM exports. React remains external and is provided by the consuming application. The shell declares `@org/ui` as a peer so the consumer explicitly supplies a compatible UI package and matching styles.

## Generate a new app locally

From the platform root, after `yarn verify`:

```bash
node packages/create-app/bin/create-app.mjs ../new-portal --packages-dir ./artifacts
cd ../new-portal
yarn install
yarn dev
```

This uses paths to local package archives. Preserve those paths while using the local demo, or switch to registry versions before moving the repository.

After publishing the packages to your private registry and configuring the scope:

```bash
yarn dlx @org/create-app@0.1.0 new-portal
cd new-portal
yarn install
yarn build
```

`@org` is a placeholder scope. Version `0.1.0` is a proposed initial release; nothing was published. The generator does not install dependencies, initialize Git, or contact your registry. It creates files and prints next steps. It refuses nonempty destinations, invalid app names, unknown flags, and missing local package archives.

## Reference adoption sequence

1. **Claims:** supplies landing text and links; filters sample claims and changes their status.
2. **Inventory:** replaces the landing page with its own dashboard; validates and receives sample stock.
3. **Onboarding:** composes `DefaultLandingPage` with custom content; validates a profile and tracks a checklist.

All three use the same shell and UI packages. Domain data, state, routing, pages, and business actions are owned by the apps. Demo state is deliberately in memory and resets when leaving a page or reloading.

## Guides

- [Architecture and customization](docs/ARCHITECTURE.md)
- [Integrating the real applications](docs/INTEGRATION.md)
- [Private registry and release procedure](docs/RELEASES.md)
- [Future monorepo migration](docs/MONOREPO-MIGRATION.md)
- [Validation results and limits](docs/VALIDATION.md)

The checked dependency baseline is explicitly pinned in the manifests and policy. It is a tested baseline, not an automatic claim of long-term security approval. Upgrade it through reviewed changes and regenerate affected package releases.
